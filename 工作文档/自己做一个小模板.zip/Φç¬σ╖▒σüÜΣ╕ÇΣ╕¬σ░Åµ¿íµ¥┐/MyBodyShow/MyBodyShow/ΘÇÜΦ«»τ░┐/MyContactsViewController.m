//
//  MyContactsViewController.m
//  MyBodyShow
//
//  Created by wlq on 2019/5/9.
//  Copyright © 2019 wlq. All rights reserved.
//

#import "MyContactsViewController.h"
#import "FangkuaiController.h"
#import "CSXGameAddController.h"
#import "WTRootViewController.h"

#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface MyContactsViewController ()<UITableViewDelegate,UITableViewDataSource>{
    UITableView *tabView;
}

@end

@implementation MyContactsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    tabView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight)];
    tabView.delegate = self;
    tabView.dataSource = self;
    [tabView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"littleC"];
    [self.view addSubview:tabView];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:{
            FangkuaiController *vc = [[FangkuaiController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 1:{
            CSXGameAddController *gameVC = [[CSXGameAddController alloc]init];
            gameVC.dimension = 4;
            gameVC.threshold = 2048;
            [self.navigationController pushViewController:gameVC animated:YES];
        }
            break;
        case 2:{
            WTRootViewController *vc = [[WTRootViewController alloc]init];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
            
        default:
            break;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:{
            return @"瞎几把小玩意";
            }
            break;
            
        default:
            return @"操蛋咯";
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tabView dequeueReusableCellWithIdentifier:@"littleC"];
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.textLabel setTextColor:[UIColor blueColor]];
    [cell.textLabel setFont:[UIFont systemFontOfSize:14]];
    switch (indexPath.row) {
        case 0:{
            cell.textLabel.text = @"  画方快";
        }
            break;
        case 1:{
            cell.textLabel.text = @"  2048小游戏";
        }
            break;
        case 2:{
            cell.textLabel.text = @"  消息回复";
        }
            break;
        default:
            break;
    }
    
    return cell;
}

@end
