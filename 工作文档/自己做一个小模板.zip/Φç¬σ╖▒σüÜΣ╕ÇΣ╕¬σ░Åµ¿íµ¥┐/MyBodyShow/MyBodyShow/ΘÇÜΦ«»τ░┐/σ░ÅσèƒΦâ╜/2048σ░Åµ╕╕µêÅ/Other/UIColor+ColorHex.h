//
//  UIColor+ColorHex.h
//  Game2048
//
//  Created by CSX on 2017/1/16.
//  Copyright © 2017年 宗盛商业. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (ColorHex)

+ (UIColor *)colorWithHexString:(NSString *)color;

@end
