//
//  FangkuaiController.m
//  MyBodyShow
//
//  Created by wlq on 2019/5/13.
//  Copyright © 2019 wlq. All rights reserved.
//

#define WeakSelf(type)  __weak typeof(type) weak##type = type;
#import "FangkuaiController.h"
#import "SDAutoLayoutModel+extendSDAutoLayout.h"
#import "SDAutoLayout.h"
#import "LuggageTableViewCell.h"

@interface FangkuaiController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView *tableView;

@end

@implementation FangkuaiController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"魔立方";
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.rowHeight = 233/2 * SCALE_WIDTH;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.tableFooterView = [[UIView alloc]init];
    [self.tableView registerClass:[LuggageTableViewCell class] forCellReuseIdentifier:@"LuggageTableViewCell"];
    [self.view addSubview:self.tableView];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    LuggageTableViewCell *cell =  [tableView dequeueReusableCellWithIdentifier:@"LuggageTableViewCell" forIndexPath:indexPath];
    cell.cellTag = indexPath.section;
    cell.sliderLBlock = ^(CGFloat sdValue, NSInteger tag) {
        
    };
    cell.sliderWBlock = ^(CGFloat sdValue, NSInteger tag) {
        
    };
    cell.sliderHBlock = ^(CGFloat sdValue, NSInteger tag) {
        
    };
    cell.sliderKGBlock = ^(CGFloat sdValue, NSInteger tag) {
        
    };
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 233 * SCALE_WIDTH;
}

@end
