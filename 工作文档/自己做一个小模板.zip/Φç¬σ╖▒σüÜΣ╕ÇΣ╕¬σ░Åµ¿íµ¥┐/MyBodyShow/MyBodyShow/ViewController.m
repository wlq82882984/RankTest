//
//  ViewController.m
//  MyBodyShow
//
//  Created by wlq on 2019/5/9.
//  Copyright © 2019 wlq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
