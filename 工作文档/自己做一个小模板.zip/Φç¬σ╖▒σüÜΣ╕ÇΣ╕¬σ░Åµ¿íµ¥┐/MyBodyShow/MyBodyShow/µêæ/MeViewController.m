//
//  MeViewController.m
//  MyBodyShow
//
//  Created by wlq on 2019/5/9.
//  Copyright © 2019 wlq. All rights reserved.
//

#import "MeViewController.h"
#import "PersonCenterCell.h"

#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface MeViewController ()<UITableViewDataSource,UITableViewDelegate>{
    UITableView *tabView;
    CGRect oldFrame;
    UIImageView *fullScreenIV;
}
@property(nonatomic,retain)NSMutableArray  *dataArray;
@end

@implementation MeViewController

- (NSMutableArray *)dataArray{
    if (_dataArray==nil) {
        _dataArray = [NSMutableArray arrayWithObjects:@[@{@"title":@"相册",@"icon":@"ff_IconShowAlbum"},@{@"title":@"收藏",@"icon":@"MoreMyFavorites"},@{@"title":@"钱包",@"icon":@"MoreMyBankCard"},@{@"title":@"卡券",@"icon":@"MyCardPackageIcon"}],
                      @[@{@"title":@"表情",@"icon":@"MoreExpressionShops"}],
                      @[@{@"title":@"设置",@"icon":@"MoreSetting"}], nil];
    }
    return _dataArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    tabView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight) style:UITableViewStyleGrouped];
    tabView.dataSource = self;
    tabView.delegate =  self;
    [self.view addSubview:tabView];
    [tabView registerNib:[UINib nibWithNibName:@"PersonCenterCell" bundle:nil] forCellReuseIdentifier:@"PersonCenterCell"];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 120;
    }else{
        return 10;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [self.dataArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.dataArray[section] count];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 120)];
        headView.backgroundColor = [UIColor groupTableViewBackgroundColor];

        UIImageView *titleView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 120)];
        titleView.contentMode = UIViewContentModeScaleToFill;
        titleView.image = [UIImage imageNamed:@"bottleBkg"];
        [headView addSubview:titleView];
        
        // ScanQRCode
        UIImageView *headicon = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 60, 60)];
        headicon.image = [UIImage imageNamed:@"xhr"];
        headicon.layer.masksToBounds = YES;
        headicon.layer.borderWidth = 2;
        headicon.layer.borderColor = [UIColor whiteColor].CGColor;
        headicon.layer.cornerRadius = 30;
        headicon.center = CGPointMake(kScreenWidth/2, 60);
        [headView addSubview:headicon];
        
        UIImageView *ScanView = [[UIImageView alloc]initWithFrame:CGRectMake(kScreenWidth - 40, 0, 40, 40)];
        ScanView.image = [UIImage imageNamed:@"ScanQRCode"];
        ScanView.layer.borderWidth = 2;
        ScanView.layer.borderColor = [UIColor whiteColor].CGColor;
        [headView addSubview:ScanView];
        
        UILabel *nameLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 100, 20)];
        nameLab.text = @"老测老";
        nameLab.textAlignment = NSTextAlignmentCenter;
        nameLab.textColor = [UIColor grayColor];
        nameLab.center = CGPointMake(kScreenWidth/2, 105);
        [headView addSubview:nameLab];
    
        return headView;
    }else{
        UIView *headView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, 10)];
        return headView;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PersonCenterCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PersonCenterCell"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.icon.image = [UIImage imageNamed:[self.dataArray[indexPath.section][indexPath.row] objectForKey:@"icon"]];
    cell.titLab.text = [self.dataArray[indexPath.section][indexPath.row] objectForKey:@"title"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

@end
