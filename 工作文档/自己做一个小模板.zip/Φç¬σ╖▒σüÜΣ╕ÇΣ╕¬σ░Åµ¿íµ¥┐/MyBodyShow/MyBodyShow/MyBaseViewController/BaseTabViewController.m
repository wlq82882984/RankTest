//
//  BaseTabViewController.m
//  MyBodyShow
//
//  Created by wlq on 2019/5/9.
//  Copyright © 2019 wlq. All rights reserved.
//

#import "BaseTabViewController.h"
#import "BaseNaViewController.h"
#import "HomeViewController.h"
#import "MyContactsViewController.h"
#import "FindViewController.h"
#import "MeViewController.h"

#define kClassKey   @"rootVCClassString"
#define kTitleKey   @"title"
#define kImgKey     @"imageName"
#define kSelImgKey  @"selectedImageName"
@interface BaseTabViewController ()

@end

@implementation BaseTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[UITabBar appearance] setTranslucent:NO];
    
    NSArray *viewsArr = @[
                          @{kClassKey:@"HomeViewController",
                            kTitleKey:@"主页",
                            kImgKey:@"tabbar_mainframe",
                            kSelImgKey:@"tabbar_mainframeHL"
                            },
                          @{kClassKey:@"MyContactsViewController",
                            kTitleKey:@"通讯录",
                            kImgKey:@"tabbar_contacts",
                            kSelImgKey:@"tabbar_contactsHL"
                            },
                          @{kClassKey:@"FindViewController",
                            kTitleKey:@"发现",
                            kImgKey:@"tabbar_discover",
                            kSelImgKey:@"tabbar_discoverHL"
                            },
                          @{kClassKey:@"MeViewController",
                            kTitleKey:@"我",
                            kImgKey:@"tabbar_me",
                            kSelImgKey:@"tabbar_meHL"
                            }
                          ];
    
    [viewsArr enumerateObjectsUsingBlock:^(NSDictionary *dict, NSUInteger idx, BOOL *stop) {
        UIViewController *vc = [NSClassFromString(dict[kClassKey]) new];
        vc.title = dict[kTitleKey];
        BaseNaViewController *nav = [[BaseNaViewController alloc] initWithRootViewController:vc];
        UITabBarItem *item = nav.tabBarItem;
        item.title = dict[kTitleKey];
        item.image = [UIImage imageNamed:dict[kImgKey]];
        item.selectedImage = [[UIImage imageNamed:dict[kSelImgKey]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        [item setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor colorWithRed:0 green:(190 / 255.0) blue:(12 / 255.0) alpha:1]} forState:UIControlStateSelected];
        [self addChildViewController:nav];
    }];
    self.selectedIndex = 0;
}

@end
